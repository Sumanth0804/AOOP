public interface Observer {
    void update(String eventType, String itemDetails);
}
