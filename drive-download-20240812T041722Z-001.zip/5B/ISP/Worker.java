package ISP;

public interface Worker {
    void work();
}
