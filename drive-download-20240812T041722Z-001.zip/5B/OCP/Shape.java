package OCP;

public abstract class Shape {
    public abstract double calculateArea();
}
