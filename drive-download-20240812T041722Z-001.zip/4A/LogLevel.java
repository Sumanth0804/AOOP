public enum LogLevel {
    INFO,
    DEBUG,
    ERROR
}
