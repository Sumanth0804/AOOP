package main.vehicle;

public class Scooter implements Vehicle {
    @Override
    public void drive() {
        System.out.println("Riding a scooter.");
    }
}
